--[[

    Description: 
        Cisco HCS platform integration with Enterprise IMS

        1. Pass through P-Charging-Vector header for INVITE, UPDATE & 200 OK.

        2. If the outgoing 200 OK response for an INVITE received, does not have a P-Charging-Vector
           header, add the P-Charging-Vector header received from the incoming INVITE.

        3. Use the configured term-ioi while adding the P-Charging-Vector to 200 OK
        
        4. If P-Charging-Vector includes a term-ioi, do not modify the existing term-ioi or add a new one.
        
        5. Pass through P-Asserted-Identity header for INVITE.
        
        6. Use the configured pai-passthru while performing pass-thru for P-Asserted-Identity.
        
    Script Parameters:
    
        term-ioi     --   Configure this parameter if the script needs to add the term-ioi parameter
                          to the P-Charging-Vector header, in the outgoing 200 OK.
        pai-passthru --   Configure this parameter if the script needs to pass-thru the P-Asserted-Identity
                          in the outgoing INVITE.
                                        
--]]


M = {}

-- Allow this header to be passed through
M.allowHeaders = {"P-Charging-Vector"}

-- Read the term-ioi value configured on the SIP Trunk
local termioi = scriptParameters.getValue("term-ioi")

-- Read the pai-passthru value configured on the SIP Trunk
local paipassthru = scriptParameters.getValue("pai-passthru")

local function handle_inbound_message(msg, store)
    -- The message should have this header
    local pcv = msg:getHeader("P-Charging-Vector")
    
    if pcv
    then
        local pt = msg:getPassThrough()
        
        -- Add the header to the pass through object, so that it will be passed through
        if pt
        then
            pt:addHeader("X-P-Charging-Vector", pcv)
        end
        
        -- If the message is an INVITE, save the header so that it can be passed back in the 200 OK response
        if store
        then
            local context = msg:getContext()
            context["PCV"] = pcv
        end
    end
end

local function handle_inbound_invite(msg)

    -- Handling PAI Header only in case of initial INVITE

    local isInitialInvite = msg:isInitialInviteRequest()    
    if isInitialInvite
    then
        if paipassthru == "true"
        then
            local pai_header = msg:getHeader("P-Asserted-Identity")
            if pai_header
            then
                local pt = msg:getPassThrough()
                pt:addHeader("X-P-Asserted-Identity", pai_header)
            end
        end
    end
    
    local diversionInInvite = msg:getHeaderValues("Diversion")

    if diversionInInvite
    then
	--Only the Last Diversion Header in the invite should be forwarded to the X-Diversion-Header
	local i = #diversionInInvite
	-- Saving the Diversion Header in Incoming Invite 
    	local pt = msg:getPassThrough()
	pt:addHeader("X-Diversion-Header", diversionInInvite[i])
    end
    
    -- If the message is an INVITE, save the header so that it can be passed back in the 200 OK response
    handle_inbound_message(msg, true)
end

local function add_term_ioi(msg)
    local pcv = msg:getHeader("P-Charging-Vector")

    if pcv
    then
        -- If the header already exists, dont modify it
        return
    end

    local context = msg:getContext()
    
    if context
    then
        -- Retrieved the saved P-Charging-Vector header
        local pcv_saved = context["PCV"]

        if pcv_saved 
        then
            -- Add the saved P-Charging-Vector header to the outbound message
            msg:addHeader("P-Charging-Vector", pcv_saved)
            
            -- Try and retrieve the "term-ioi" parameter from P-Charging-Vector header
            local termioi_existing  = msg:getHeaderValueParameter("P-Charging-Vector", "term-ioi")
            
            if termioi_existing
            then
                -- If term-ioi already exists in the header, do nothing
                return
            end

            if termioi
            then
                -- Add the configured term-ioi header parameter
                msg:addHeaderValueParameter("P-Charging-Vector", "term-ioi", termioi)
            end
        end
    end
end

local function handle_inbound_ack(msg)
    local context = msg:getContext()
    
    -- Clean up the saved P-Charging-Vector on receiving an ACK
    if context
    then
        local PCV = context["PCV"]
        
        if PCV
        then
            context["PCV"] = nil
        end
    end
end

-- check if there are any diversion Diversion header with reason
-- other than follow-me (SNR). In such cases, P-Charging-Header should 
-- not be passed through
local function checkDiversionHeaders(msg)

    local diversion = msg:getHeaderValues("Diversion")    

    if diversion
    then       
        local i = 1

        -- if there are multiple diversion headers found then parse through all and 
        -- return true if there are any header with reason other than "follow-me"
        while diversion[i] 
        do
            local paramName  = string.match(diversion[i], "reason=")
            local paramValue = string.match(diversion[i], "reason=follow%-me")
            
            if paramName == "reason=" and paramValue == nil
            then 
		xDiversionHeader = msg:getHeader("X-Diversion-Header")
		if xDiversionHeader
		then		     
		    local xdiversion_uri = msg:getUri("X-Diversion-Header")
		    local xdiversion_uri_only= string.match(xdiversion_uri, ":[^;%s]+")
		    --Check if this Diversion header is due to the inbound Diversion header.
		    if xdiversion_uri_only and diversion[i]:upper():find(xdiversion_uri_only:upper(),1,true) 
		    then
			-- This diversion header is from the inbound INVITE. 
                    else
			return true
		    end
		else
		    return true
		end  
            end
            i = i + 1
        end
    end
    return false
end

local function handle_outbound_invite(msg)

    if paipassthru == "true"
    then
        local x_pai_header = msg:getHeader("X-P-Asserted-Identity")
        local pai_header = msg:getHeader("P-asserted-Identity")
        
        if pai_header and x_pai_header
        then
            msg:modifyHeader("P-Asserted-Identity", x_pai_header)
            msg:removeHeader("X-P-Asserted-Identity")
        end
    end
    
    -- check if we have X-P-Charging-Vector present in the outbound msg
    local x_pcv_header = msg:getHeader("X-P-Charging-Vector")
    
    if x_pcv_header
    then
    
        -- remove X-P-Charging-Vector from the outgoing INVITE
        msg:removeHeader("X-P-Charging-Vector")
   
        -- check if we have P-Charging-Vector header is present in the outbound message
        local pcv_header = msg:getHeader("P-Charging-Vector")
    
        if pcv_header
        then
           -- if we have a P-Charging-Vector header leave it unchanged
        else

           -- check if there are any diversion Diversion header with reason
           -- other than follow-me (SNR). In such cases, P-Charging-Header should
           -- not be passed through
   
           local doNotPassthrough = checkDiversionHeaders(msg)     
           if doNotPassthrough == false
           then
              --  add the PCV header 
              msg:addHeader("P-Charging-Vector", x_pcv_header)
           end
       
        end
    end
    
    --removes X-Diversion-Header from the outgoing INVITE
    local x_diversion_header = msg:getHeader("X-Diversion-Header")
    if x_diversion_header
    then
       msg:removeHeader("X-Diversion-Header")
    end     
end


local function handle_outbound_message(msg)
    local x_pcv_header = msg:getHeader("X-P-Charging-Vector")
    local pcv_header = msg:getHeader("P-Charging-Vector")
    
    if x_pcv_header
    then
        -- remove X-P-Charging-Vector from outbound msg
        msg:removeHeader("X-P-Charging-Vector")
        
        -- if we have a P-Charging-Vector header leave it unchanged
        if pcv_header 
        then
            return
        end
        
        -- else add the header 
        msg:addHeader("P-Charging-Vector", x_pcv_header)
    end
    
end

M.inbound_ACK          = handle_inbound_ack
M.inbound_INVITE       = handle_inbound_invite
M.inbound_UPDATE       = handle_inbound_message
M.inbound_200_INVITE   = handle_inbound_message
M.outbound_200_INVITE  = add_term_ioi
M.outbound_INVITE      = handle_outbound_invite
M.outbound_UPDATE      = handle_outbound_message
M.outbound_200_INVITE  = handle_outbound_message

return M
