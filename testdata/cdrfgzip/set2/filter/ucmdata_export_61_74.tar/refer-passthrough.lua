--[[
    This script is used to trigger REFER pass through. The following conditions
    must be met in order for the REFER to be passed through:
 
a.  The inbound REFER must be in-dialog

b.  The Refer-To header must not contain an embedded Replaces header

c.  The other call leg must be a SIP Trunk

d.  The endpoint represented by the other call leg must support REFER

 
    If any of the conditions above are not met, the REFER is processed locally by
    Cisco Unified Communications Manager.
--]]

M={}

function M.inbound_REFER(msg)
    -- the message should have the following headers
    local to = msg:getHeader("To")
    local referto = msg:getHeader("Refer-To")
    local referredby = msg:getHeader("Referred-By")

    if not to or not referto
    then
        return
    end

    -- see if the Refer-To header contains an embedded Replaces header
    if referto:upper():find("REPLACES")
    then
        -- pass through is not supported if the Refer-To contains an embedded Replaces header
        return
    end

    -- see if the REFER is in-dialog
    if not to:upper():find("TAG=")
    then
        -- pass through is not supported for out-of-dialog REFER
        return
    end

    -- this is an in-dialog REFER without an embedded Replaces header; pass it through
    local pt = msg:getPassThrough()
    if pt
    then  
        pt:addHeader("Refer-To", referto)
        if(referredby)
        then
            pt:addHeader("Referred-By", referredby)
        end
        trace.format("Passing through inbound REFER")
    end   
end

return M
