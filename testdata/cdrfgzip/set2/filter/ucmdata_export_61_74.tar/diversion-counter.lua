
--[[

    Description: 
        Diversion Counter Handling For Call Forward Scenarios. This script should be attached to both
		inbound and outbound trunk.
	
	1. Pass through counter parameter in case Basic Tandem call with NO Diversion within the cluster.
	2. Handling of counter parameter for Tandem call with one or more Diversion within CUCM cluster 
	3. Handling of counter parameter for Tandem call when inbound INVITE has more than two Diversion 
		headers and there is also one or more Diversion within CUCM cluster 

    Exceptions:
	1. This script is only applicable for Tandem (trunk-to-trunk) calls.
	2. If there are multiple diversions within the cluster, the Diversion counter parameter will be 
		increase just by 1.
--]]



M = {}
local tc = "Diversion"

function M.inbound_INVITE(msg)

    if msg:isReInviteRequest()
    then
        return
    end

    -- Get the Diversion header. If no Diversion header then return. 
    local diversion = msg:getHeader("Diversion")
    if not diversion
    then
        return
    end

    local pt = msg:getPassThrough()
    pt:addHeader("X-Diversion", diversion)

end

function M.outbound_INVITE(msg)

	-- This script is applicable only for initial INVITE.
        if msg:isReInviteRequest()
        then
                return
        end

	-- Get Diversion header. If there is no Diversion header then return
        local diversion = msg:getHeader("Diversion")

        if not diversion
        then
                return
        end

        -- Get X-Diversion Header. If there was no X-Diversion header then return

        local xDiversion = msg:getHeader("X-Diversion")

        if not xDiversion
        then
                return
        end

	-- Get URI from Diversion header
        local divString = msg:getUri("Diversion")
        if divString
        then
		
		-- Parse URI and get DN and Host
                local divuri = sipUtils.parseUri(divString)
                if divuri
                then
                        lrn_user = divuri:getUser()
                        lrn_host = divuri:getHost()
                end
        end

	-- Get URI from X-Diversion header
        local xdivString = msg:getUri("X-Diversion")
        if xdivString
        then
		-- Parse URI and get DN and Host
                local xdivuri = sipUtils.parseUri(xdivString)
                if xdivuri
                then
                        xlrn_user = xdivuri:getUser()
                        xlrn_host = xdivuri:getHost()
                end
        end

	-- Get counter parameter value from inbound diversion (X-Diversion). 
	local counter = msg:getHeaderValueParameter("X-Diversion", "counter")

	-- If new LRN is different from incoming LRN, that means there was a local
        -- call forward on UCM, so increase the counter.
        if not ( string.match(lrn_user, xlrn_user) and string.match(lrn_host, xlrn_host) )
        then
                 
		-- If there is no counter parameter, then find out how many Diversion
		-- headers are there. Set the counter to no. of Diversion Header.
		-- If there is a counter value, just increase it by 1.
                if not counter
                then        

                       	local xdiv = msg:getHeaderValues("X-Diversion")
			if #xdiv > 1
			then
                       		counter = #xdiv 
			end

                 else
                       counter = counter + 1
                end

                msg:addHeaderValueParameter("Diversion","counter", counter)
	else
		-- As there is no local call forward, so pass through the counter parameter.
                if counter
                then
			msg:addHeaderValueParameter("Diversion","counter", counter)
		end

        end
        msg:removeHeader("X-Diversion")
end

return M
