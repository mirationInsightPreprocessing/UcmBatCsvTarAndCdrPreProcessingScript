--[[

   Description:

   Cisco Unified CM will drop any SIP header that it does not recognize.  
   This script will pass through transparently one such header, "x-att-loop", from the inbound SIP leg to outbound SIP leg.
   This script must be installed on the SIP leg (or legs) where the above header is received and it will be passed through
   transparently to other SIP leg.

   Script Parameters:
   Configure the following script parameters on the SIP Normalization Script in Unified Communications Manager (UCM)
        Memory Threshold -- 100 kilobytes
        Lua Instruction Threshold -- 1000 instructions

--]]

M = {}

M.allowHeaders = {"x-att-loop"}

function M.inbound_INVITE(msg)

  local ntcorrid = msg:getHeader("x-att-loop")
  if ntcorrid
  then
    pt = msg:getPassThrough()
    pt:addHeader("x-att-loop", ntcorrid)
  end

end
return M

